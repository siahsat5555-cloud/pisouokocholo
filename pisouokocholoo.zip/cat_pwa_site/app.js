/* ---------- state ---------- */
var STORAGE_KEY = 'catPageStateV2';
var ACCESSORY_POOL = ['🎩 کلاه شیک','👓 عینک بامزه','🧣 شال گردن','🌟 یقه ستاره‌ای','🎗️ روبان طلایی','👑 تاج کوچولو','🕶️ عینک آفتابی'];

var state = {
  answered: false,
  food: 85, play: 85, cuddle: 85,
  catName: null,
  lastUpdate: Date.now(),
  lastOpenDay: null,
  streakDays: 0,
  unlockedAccessories: [],
  journal: [],
  totalCuddles: 0,
  totalKisses: 0,
  totalHeadPets: 0,
  bowOffset: {dx:0, dy:0},
  milestones: {},
  xp: 0,
  dailyLog: null,
  dailySpecial: null,
  unlockedTitles: []
};

var TITLE_LEVELS = [
  {min:1, max:1, title:'آشنای تازه'},
  {min:2, max:3, title:'دوست کوچولو'},
  {min:4, max:6, title:'همدم روزهای خوب'},
  {min:7, max:10, title:'بهترین دوست'},
  {min:11, max:15, title:'همراه همیشگی'},
  {min:16, max:99999, title:'عشق واقعی 💛'}
];
function levelFromXp(xp){ return Math.floor(xp/100) + 1; }
function titleForLevel(lv){
  for(var i=0;i<TITLE_LEVELS.length;i++){
    if(lv >= TITLE_LEVELS[i].min && lv <= TITLE_LEVELS[i].max) return TITLE_LEVELS[i].title;
  }
  return TITLE_LEVELS[TITLE_LEVELS.length-1].title;
}
function addXp(amount){
  var beforeLv = levelFromXp(state.xp);
  state.xp += amount;
  var afterLv = levelFromXp(state.xp);
  if(afterLv > beforeLv){
    addJournal('امروز رابطه‌مون یه‌پله رفت بالا — الان دیگه "' + titleForLevel(afterLv) + '"شم 💫');
    setTimeout(function(){ showToast('سطح جدید: ' + titleForLevel(afterLv) + ' 💫'); }, 300);
  }
  renderLevel();
}
function renderLevel(){
  var el = document.getElementById('levelTag');
  if(!el) return;
  var lv = levelFromXp(state.xp);
  el.style.display = 'inline-block';
  var pct = state.xp % 100;
  el.innerHTML = '💫 سطح ' + lv + ' — ' + titleForLevel(lv) +
    '<div class="levelBarWrap"><div class="levelBarFill" style="width:' + pct + '%"></div></div>';
}

/* ---------- daily interaction tracking (for the cat's own diary) ---------- */
function trackInteraction(n){
  var t = todayKey();
  if(!state.dailyLog || state.dailyLog.date !== t){
    state.dailyLog = {date: t, count: 0};
  }
  state.dailyLog.count += (n || 1);
}
function writeYesterdayDiary(prevCount){
  var name = state.catName || 'گربه';
  var pool;
  if(prevCount === 0){
    pool = [
      'دیروز هیچ‌کس بهم سر نزد... دلم خیلی گرفت 😔',
      'دیروز کاملاً تنها بودم، دلم برای صاحبم تنگ شده بود 🥺',
      'دیروز هیچکی باهام بازی نکرد، غمگین بودم 😢'
    ];
  } else if(prevCount <= 3){
    pool = [
      'دیروز یه‌کم بهم سر زدن، خوب بود ولی دلم بیشتر می‌خواست 🙂',
      'دیروز یه‌ذره وقت باهام گذروندن، ممنونم — ولی جا داره بیشتر باشه 🐾'
    ];
  } else if(prevCount <= 8){
    pool = [
      'دیروز خیلی بهم رسیدن، حالم خوب بود 😊',
      'دیروز روز خوبی بود، کلی باهام بازی کردن 🎾',
      'دیروز صاحبم چندبار اومد سراغم، خوشحال بودم 😊'
    ];
  } else {
    pool = [
      'دیروز صاحبم عالی بود، کلی بهم رسید، خیلی خوشحال بودم! 💛',
      'دیروز بهترین روزم بود، همش باهام بودن 😻',
      'دیروز حس کردم چقدر براش مهمم، عاشقشم 💛'
    ];
  }
  addJournal(pick(pool));
}

function saveState(){
  try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }catch(e){}
}
function loadState(){
  try{
    var raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return null;
    return JSON.parse(raw);
  }catch(e){ return null; }
}
function addJournal(title){
  state.journal.unshift({title:title, date: Date.now()});
}
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function logMilestone(key, textPool){
  if(!state.milestones) state.milestones = {};
  if(state.milestones[key]) return;
  state.milestones[key] = true;
  addJournal(pick(textPool));
}

/* ---------- questions ---------- */
function nextQ(n){
  document.querySelectorAll('.q').forEach(function(el){el.classList.remove('active');});
  document.getElementById('q'+n).classList.add('active');
}
function finishQuestions(){
  state.answered = true;
  applyDailyReward();
  showScr('home');
  maybeNamePrompt();
  setupBowDrag();
  applyBowOffset();
}

/* ---------- daily reward / streak ---------- */
function todayKey(){
  var d = new Date();
  return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();
}
function applyDailyReward(){
  var today = todayKey();
  if(state.lastOpenDay === today) return;
  if(state.dailyLog && state.dailyLog.date !== today){
    writeYesterdayDiary(state.dailyLog.count);
  } else if(state.lastOpenDay && state.lastOpenDay !== today){
    writeYesterdayDiary(0);
  }
  state.dailyLog = {date: today, count: 0};
  var specialPool = [
    {key:'playBoost', text:'😼 امروز گربه شیطونه — بازی‌ها امتیاز بیشتری میدن!'},
    {key:'slowDrain', text:'🎉 امروز گربه سرحاله — نوارها کندتر خالی می‌شن!'},
    {key:'normal', text:'🐾 یه روز عادی و آروم'}
  ];
  state.dailySpecial = pick(specialPool);
  var wasYesterday = false;
  if(state.lastOpenDay){
    var prev = new Date(state.lastOpenDay.split('-')[0], state.lastOpenDay.split('-')[1]-1, state.lastOpenDay.split('-')[2]);
    var diffDays = Math.round((new Date(new Date().toDateString()) - new Date(prev.toDateString())) / 86400000);
    wasYesterday = diffDays === 1;
  }
  state.streakDays = wasYesterday ? state.streakDays + 1 : 1;
  state.lastOpenDay = today;
  if(state.streakDays === 7){
    addJournal('یک هفته‌ی تمام هرروز اومدم سراغش — این یعنی واقعا برام مهمه 🎉');
  }
  if(state.streakDays === 30){
    addJournal('یک ماهه که هرروز میام سراغش. دیگه نمیشه نبود اون رو تصور کرد 🎉');
  }
  var remaining = ACCESSORY_POOL.filter(function(a){ return state.unlockedAccessories.indexOf(a) === -1; });
  if(remaining.length){
    var gift = remaining[Math.floor(Math.random()*remaining.length)];
    state.unlockedAccessories.push(gift);
    setTimeout(function(){ showToast('هدیه‌ی امروزت: ' + gift + ' 🎁'); }, 500);
  }
  saveState();
}

/* ---------- screens ---------- */
var started = false;
var decayInterval = null;

function showScr(name){
  document.querySelectorAll('.q').forEach(function(el){el.classList.remove('active');});
  document.querySelectorAll('.scr').forEach(function(el){el.classList.remove('active');});
  document.getElementById('scr-'+name).classList.add('active');
  if(!started){
    started = true;
    decayInterval = setInterval(decay, 6000);
    setupShakeButton();
    setInterval(maybeRareHeartRain, 120000);
    setInterval(maybeSpawnGiftBox, 45000);
    updateNightTint();
    setInterval(updateNightTint, 60000);
  }
  if(name !== 'play') resetTapGame();
  if(name === 'home'){
    saveState();
    renderStreak();
    renderTitle();
    renderLevel();
    renderDailySpecial();
  }
  if(name === 'journal') renderJournal();
  if(name === 'yarn') initYarnBall();
}

function renderTitle(){
  document.getElementById('appTitleText').textContent = state.catName ? ('گربه‌ی ' + state.catName) : 'گربه من';
}
function renderStreak(){
  var el = document.getElementById('streakTag');
  if(state.streakDays > 0){
    el.style.display = 'inline-block';
    el.textContent = '🔥 ' + state.streakDays + ' روز پیاپی';
  } else {
    el.style.display = 'none';
  }
}
function renderDailySpecial(){
  var el = document.getElementById('dailySpecialTag');
  if(state.dailySpecial && state.dailySpecial.text){
    el.style.display = 'inline-block';
    el.textContent = state.dailySpecial.text;
  } else {
    el.style.display = 'none';
  }
}

/* ---------- decay / mood ---------- */
function decay(){
  var rate = 100/3600; // fully drains in 1 hour
  var mult = (state.dailySpecial && state.dailySpecial.key === 'slowDrain') ? 0.5 : 1;
  state.food = Math.max(0, state.food - rate*6*mult);
  state.play = Math.max(0, state.play - rate*6*mult);
  state.cuddle = Math.max(0, state.cuddle - rate*6*mult);
  updateBars(); updateMood();
  saveState();
}
function barColor(v){ if(v<30) return '#E24B4A'; if(v<60) return '#EF9F27'; return '#639922'; }
function updateBars(){
  ['food','play','cuddle'].forEach(function(k){
    var el = document.getElementById('fill-'+k);
    if(!el) return;
    el.style.width = state[k] + '%';
    el.style.background = barColor(state[k]);
  });
}
var mood = 'happy';
function computeMood(){
  if(state.food<=15 || state.play<=15 || state.cuddle<=15) return 'sad';
  if(state.food>=70 && state.play>=70 && state.cuddle>=70) return 'happy';
  return 'normal';
}
function updateMood(){
  var nm = computeMood();
  if(nm === mood) return;
  mood = nm;
  var standing = document.getElementById('catStanding');
  var lying = document.getElementById('catLying');
  var mouthN = document.getElementById('mouthNormal');
  var mouthH = document.getElementById('mouthHappy');
  var flower = document.getElementById('flowerGroup');
  var msg = document.getElementById('catMsg');
  var name = state.catName || 'گربه';
  if(mood === 'sad'){
    standing.style.display = 'none';
    lying.style.display = 'block';
    msg.textContent = name + ' ناراحته... یکم بهش برس 🥺';
    playMeow('sad');
  } else {
    standing.style.display = 'block';
    lying.style.display = 'none';
    if(mood === 'happy'){
      mouthN.style.display = 'none';
      mouthH.style.display = 'block';
      flower.style.animation = 'pop 0.5s cubic-bezier(.34,1.56,.64,1) forwards';
      msg.textContent = name + ' خیلی خوشحاله و برات گل آورد 🌸';
      playMeow('happy');
      logMilestone('firstFlower', [
        'اولین باری که ' + name + ' برام گل آورد — دلم آب شد 🌸',
        'یه گل کوچولو از ' + name + '، یه دنیا خوشحالی برام 🌸',
        'یادمه چقدر ذوق کردم وقتی ' + name + ' اولین گلش رو داد 🌸'
      ]);
      if(Math.random() < 0.08) triggerGoldenHeart();
    } else {
      mouthN.style.display = 'block';
      mouthH.style.display = 'none';
      flower.style.opacity = '0';
      flower.style.animation = 'none';
      msg.textContent = name + ' حالش خوبه 🐾';
      playMeow('normal');
    }
    saveState();
  }
}

/* ---------- belly / kiss ---------- */
var bellyCount = 0, bellyTimer = null;
function bellyClick(){
  bellyCount++;
  vibrate(15);
  clearTimeout(bellyTimer);
  bellyTimer = setTimeout(function(){ bellyCount = 0; }, 1500);
  if(bellyCount >= 5){
    bellyCount = 0;
    runAndKiss();
  }
}
function runAndKiss(){
  vibrate([20,30,20]);
  state.totalKisses++;
  logMilestone('firstKiss', [
    'اولین ماچ ' + (state.catName||'گربه') + '، هنوز رو لپم مونده 😽',
    'یه ماچ کوچولو که دلمو برد — اولین بارش بود 😽',
    'همون لحظه‌ای که ' + (state.catName||'گربه') + ' برای اولین بار ماچم کرد 😽'
  ]);
  if(state.totalKisses > 0 && state.totalKisses % 10 === 0){
    addJournal(state.totalKisses + ' تا ماچ تا الان ازش گرفتم 😽💕');
  }
  trackInteraction(1);
  addXp(5);
  saveState();
  var svgEl = document.getElementById('catSvg');
  var stage = document.getElementById('catStage');
  var msg = document.getElementById('catMsg');
  svgEl.classList.add('running');
  for(var i=0;i<5;i++){
    (function(i){
      setTimeout(function(){
        var h = document.createElement('div');
        h.className = 'heart';
        h.textContent = (i%2===0) ? '❤️' : '💕';
        h.style.left = (30+Math.random()*180)+'px';
        h.style.bottom = (20+Math.random()*40)+'px';
        stage.appendChild(h);
        setTimeout(function(){ h.remove(); }, 1200);
      }, i*120);
    })(i);
  }
  var prevMsg = msg.textContent;
  msg.textContent = '😽 ماچ ماچ!';
  setTimeout(function(){
    svgEl.classList.remove('running');
    msg.textContent = prevMsg;
  }, 1700);
}

/* ---------- head pet: purr + blush ---------- */
function headClick(){
  vibrate([10,10,10]);
  playPurr();
  var bl = document.getElementById('blushL');
  var br = document.getElementById('blushR');
  [bl, br].forEach(function(b){
    b.setAttribute('fill', '#E8557E');
    b.setAttribute('opacity', '0.95');
    b.setAttribute('r', '11');
  });
  setTimeout(function(){
    [bl, br].forEach(function(b){
      b.setAttribute('fill', '#F4C0D1');
      b.setAttribute('opacity', '0.6');
      b.setAttribute('r', '9');
    });
  }, 1600);
  state.totalHeadPets = (state.totalHeadPets||0) + 1;
  trackInteraction(1);
  addXp(3);
  logMilestone('firstHeadPet', [
    'اولین بار سرشو نوازش کردم و شروع کرد به خرخر کردن، انگار داشت میگفت خیلی خوشحالم 😻',
    'دستمو رو سرش کشیدم و همون لحظه شروع کرد به خرخر — یکی از قشنگ‌ترین لحظه‌ها 😻',
    'وقتی سرشو نوازش کردم و صدای خرخرش رو شنیدم، دلم لرزید 😻'
  ]);
  saveState();
}

/* ---------- synthesized cat sounds (Web Audio API placeholder — not real recordings) ---------- */
function getAudioCtx(){
  if(!window._audioCtx){
    try{ window._audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }catch(e){ return null; }
  }
  if(window._audioCtx.state === 'suspended'){ window._audioCtx.resume(); }
  return window._audioCtx;
}
function playMeow(moodType){
  var ctx = getAudioCtx();
  if(!ctx) return;
  var now = ctx.currentTime;
  var osc = ctx.createOscillator();
  var gain = ctx.createGain();
  osc.connect(gain); gain.connect(ctx.destination);
  var startFreq, peakFreq, endFreq, dur;
  if(moodType === 'happy'){ startFreq=620; peakFreq=920; endFreq=760; dur=0.32; }
  else if(moodType === 'sad'){ startFreq=520; peakFreq=430; endFreq=330; dur=0.6; }
  else { startFreq=560; peakFreq=680; endFreq=520; dur=0.4; }
  osc.type = 'sine';
  osc.frequency.setValueAtTime(startFreq, now);
  osc.frequency.linearRampToValueAtTime(peakFreq, now + dur*0.4);
  osc.frequency.linearRampToValueAtTime(endFreq, now + dur);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.22, now + 0.06);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
  osc.start(now);
  osc.stop(now + dur + 0.05);
}
function playPurr(){
  var ctx = getAudioCtx();
  if(!ctx) return;
  var now = ctx.currentTime;
  var dur = 1.5;
  var osc = ctx.createOscillator();
  var lfo = ctx.createOscillator();
  var lfoGain = ctx.createGain();
  var mainGain = ctx.createGain();
  osc.type = 'sine'; osc.frequency.value = 42;
  lfo.type = 'sine'; lfo.frequency.value = 26;
  lfoGain.gain.value = 0.4;
  mainGain.gain.value = 0.12;
  lfo.connect(lfoGain);
  lfoGain.connect(mainGain.gain);
  osc.connect(mainGain);
  mainGain.connect(ctx.destination);
  osc.start(now); lfo.start(now);
  osc.stop(now + dur); lfo.stop(now + dur);
}

/* ---------- bow: tap to recolor, drag to reposition ---------- */
var bowDrag = {active:false, moved:false, startX:0, startY:0};
function setupBowDrag(){
  var bow = document.getElementById('bowGroup');
  var svg = document.getElementById('catSvg');
  bow.style.touchAction = 'none';
  bow.addEventListener('pointerdown', function(e){
    bowDrag.active = true; bowDrag.moved = false;
    bowDrag.startX = e.clientX; bowDrag.startY = e.clientY;
    bow.setPointerCapture(e.pointerId);
  });
  bow.addEventListener('pointermove', function(e){
    if(!bowDrag.active) return;
    var dxPx = e.clientX - bowDrag.startX;
    var dyPx = e.clientY - bowDrag.startY;
    if(Math.abs(dxPx) > 4 || Math.abs(dyPx) > 4) bowDrag.moved = true;
    var rect = svg.getBoundingClientRect();
    var scaleX = rect.width / 200, scaleY = rect.height / 190;
    var newDx = state.bowOffset.dx + dxPx/scaleX;
    var newDy = state.bowOffset.dy + dyPx/scaleY;
    newDx = Math.max(-40, Math.min(40, newDx));
    newDy = Math.max(-50, Math.min(30, newDy));
    bow.setAttribute('transform', 'translate(' + newDx + ',' + newDy + ')');
    bow.dataset.tmpDx = newDx; bow.dataset.tmpDy = newDy;
  });
  bow.addEventListener('pointerup', function(e){
    if(!bowDrag.active) return;
    bowDrag.active = false;
    if(bowDrag.moved){
      state.bowOffset.dx = parseFloat(bow.dataset.tmpDx || state.bowOffset.dx);
      state.bowOffset.dy = parseFloat(bow.dataset.tmpDy || state.bowOffset.dy);
      logMilestone('firstBowMove', ['امروز جای روبانش رو عوض کردم، یه‌جورایی مال خودم‌تر شد 🎀']);
      saveState();
    } else {
      bowClick(e);
    }
  });
}
function applyBowOffset(){
  var bow = document.getElementById('bowGroup');
  if(state.bowOffset && (state.bowOffset.dx || state.bowOffset.dy)){
    bow.setAttribute('transform', 'translate(' + state.bowOffset.dx + ',' + state.bowOffset.dy + ')');
  }
}
var bowMsgs = ['بهت میاد! 🎀','چه رنگ قشنگی!','این یکی محبوبمه','😍','رنگ به رنگ میشه','ایول چه شیک'];
function bowClick(ev){
  ev.stopPropagation();
  var hue = Math.floor(Math.random()*360);
  var color = 'hsl('+hue+',75%,65%)';
  var darker = 'hsl('+hue+',70%,50%)';
  var g = document.getElementById('bowGroup');
  g.querySelectorAll('polygon').forEach(function(p){ p.setAttribute('fill', color); });
  g.querySelector('circle').setAttribute('fill', darker);
  g.classList.remove('pop');
  void g.offsetWidth;
  g.classList.add('pop');
  vibrate(10);
  var stage = document.getElementById('catStage');
  var m = document.createElement('div');
  m.className = 'bowmsg';
  m.textContent = bowMsgs[Math.floor(Math.random()*bowMsgs.length)];
  m.style.left = 'calc(50% + ' + (Math.random()*30-15) + 'px)';
  m.style.bottom = '95px';
  stage.appendChild(m);
  setTimeout(function(){ m.remove(); }, 1300);
}

/* ---------- food ---------- */
function feed(amount, note){
  state.food = Math.min(100, state.food + amount);
  updateBars(); updateMood();
  trackInteraction(1);
  addXp(5);
  saveState();
  document.getElementById('foodMsg').textContent = note + ' (+' + amount + ' غذا)';
}

/* ---------- generic tap games ---------- */
var gameState = null;
function resetTapGame(){
  gameState = null;
  var area = document.getElementById('gameArea');
  if(area) area.style.display = 'none';
  var box = document.getElementById('gamebox');
  if(box) box.innerHTML = '';
  var pm = document.getElementById('playMsg');
  if(pm) pm.textContent = '';
}
function startTapGame(type, emoji, title){
  resetTapGame();
  document.getElementById('gameArea').style.display = 'block';
  gameState = {type:type, emoji:emoji, score:0, target:5};
  document.getElementById('gameProgress').textContent = '۰ از ۵ — ' + title;
  spawnTarget();
}
function spawnTarget(){
  if(!gameState) return;
  var box = document.getElementById('gamebox');
  box.innerHTML = '';
  var t = document.createElement('div');
  t.className = 'gametarget';
  t.textContent = gameState.emoji;
  t.style.top = (10+Math.random()*75) + '%';
  t.style.left = (10+Math.random()*75) + '%';
  t.onclick = hitTarget;
  box.appendChild(t);
}
function hitTarget(){
  if(!gameState) return;
  gameState.score++;
  vibrate(10);
  document.getElementById('gameProgress').textContent = gameState.score + ' از ' + gameState.target;
  if(gameState.score >= gameState.target){
    var boost = (state.dailySpecial && state.dailySpecial.key === 'playBoost') ? 35 : 25;
    state.play = Math.min(100, state.play + boost);
    updateBars(); updateMood();
    trackInteraction(1);
    addXp(15);
    saveState();
    document.getElementById('gamebox').innerHTML = '';
    document.getElementById('playMsg').textContent = 'آفرین! گربه خیلی خوشحال شد (+' + boost + ' بازی)';
    gameState = null;
  } else {
    spawnTarget();
  }
}

/* ---------- yarn throw game ---------- */
var yarnCatches = 0;
var yarnDrag = null;
function initYarnBall(){
  var box = document.getElementById('yarnBox');
  var old = box.querySelector('.yarnBall');
  if(old) old.remove();
  var ball = document.createElement('div');
  ball.className = 'yarnBall';
  ball.textContent = '🧶';
  ball.style.left = '20px';
  ball.style.top = '20px';
  box.appendChild(ball);
  attachYarnEvents(ball, box);
}
function attachYarnEvents(ball, box){
  var startX, startY, curX, curY, dragging = false;
  function down(x,y){
    dragging = true;
    startX = x; startY = y; curX = x; curY = y;
    ball.style.cursor = 'grabbing';
  }
  function move(x,y){
    if(!dragging) return;
    curX = x; curY = y;
    var rect = box.getBoundingClientRect();
    var left = Math.max(0, Math.min(rect.width-30, x - rect.left - 15));
    var top = Math.max(0, Math.min(rect.height-30, y - rect.top - 15));
    ball.style.left = left + 'px';
    ball.style.top = top + 'px';
  }
  function up(){
    if(!dragging) return;
    dragging = false;
    var dx = curX - startX, dy = curY - startY;
    var dist = Math.sqrt(dx*dx + dy*dy);
    if(dist > 20){
      throwBall(ball, box, dx, dy);
    }
  }
  ball.addEventListener('pointerdown', function(e){ down(e.clientX, e.clientY); ball.setPointerCapture(e.pointerId); });
  ball.addEventListener('pointermove', function(e){ move(e.clientX, e.clientY); });
  ball.addEventListener('pointerup', function(e){ up(); });
}
function throwBall(ball, box, dx, dy){
  var rect = box.getBoundingClientRect();
  var curLeft = parseFloat(ball.style.left);
  var curTop = parseFloat(ball.style.top);
  var vx = dx / 12, vy = dy / 12;
  var frames = 0;
  function step(){
    frames++;
    curLeft += vx;
    curTop += vy;
    vx *= 0.94; vy *= 0.94;
    ball.style.left = curLeft + 'px';
    ball.style.top = curTop + 'px';
    var catchX = rect.width/2 - 22, catchY = rect.height - 44;
    var hitCatch = Math.abs(curLeft - catchX) < 30 && Math.abs(curTop - catchY) < 30;
    var outOfBounds = curLeft < -40 || curLeft > rect.width+10 || curTop < -40 || curTop > rect.height+10;
    if(hitCatch){
      onYarnCatch();
      resetYarnBall(ball);
      return;
    }
    if(outOfBounds || frames > 90){
      resetYarnBall(ball);
      document.getElementById('yarnMsg').textContent = 'اوه، رد شد! دوباره امتحان کن';
      return;
    }
    requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
function resetYarnBall(ball){
  ball.style.left = '20px';
  ball.style.top = '20px';
  ball.style.cursor = 'grab';
}
function onYarnCatch(){
  yarnCatches++;
  vibrate([15,20,15]);
  document.getElementById('yarnProgress').textContent = Math.min(yarnCatches,3) + ' گرفتن از ۳';
  document.getElementById('yarnMsg').textContent = 'گرفتش! 🎉';
  if(yarnCatches >= 3){
    var boost = (state.dailySpecial && state.dailySpecial.key === 'playBoost') ? 35 : 25;
    state.play = Math.min(100, state.play + boost);
    updateBars(); updateMood();
    trackInteraction(1);
    addXp(15);
    saveState();
    document.getElementById('yarnMsg').textContent = 'گربه عاشق این بازی شد! (+' + boost + ' بازی)';
    yarnCatches = 0;
    document.getElementById('yarnProgress').textContent = '۰ گرفتن از ۳';
  }
}

/* ---------- cuddle ---------- */
var cuddleCount = 0;
function cuddleClick(){
  cuddleCount++;
  vibrate(12);
  var stage = document.getElementById('cuddleStage');
  stage.style.animation = 'none';
  void stage.offsetWidth;
  stage.style.animation = 'jump 0.3s ease';
  document.getElementById('cuddleProgress').textContent = Math.min(cuddleCount,6) + ' از ۶ نوازش';
  var h = document.createElement('div');
  h.className = 'heart';
  h.textContent = '💕';
  h.style.left = (40+Math.random()*40) + '%';
  h.style.bottom = '40%';
  stage.appendChild(h);
  setTimeout(function(){ h.remove(); }, 1100);
  if(cuddleCount >= 6){
    state.cuddle = Math.min(100, state.cuddle + 30);
    state.totalCuddles++;
    logMilestone('firstCuddle', [
      'اولین باری که ' + (state.catName||'گربه') + ' رو بغل کردم و آروم شدم 🤗',
      'یه بغل گرم از ' + (state.catName||'گربه')+'، اولین باری که این‌کارو کردم 🤗',
      'همون لحظه که تو بغلم آروم گرفت 🤗'
    ]);
    if(state.totalCuddles > 0 && state.totalCuddles % 10 === 0){
      addJournal(state.totalCuddles + ' بار تا الان بغلش کردم، هنوزم دلم می‌خواد بازم بکنم 🤗');
    }
    trackInteraction(1);
    addXp(15);
    updateBars(); updateMood();
    saveState();
    vibrate([20,30,20]);
    document.getElementById('cuddleMsg').textContent = 'گربه رو بغل کردی، خیلی راضیه 🤗 (+30 بغل)';
    cuddleCount = 0;
    document.getElementById('cuddleProgress').textContent = '۰ از ۶ نوازش';
  }
}

/* ---------- naming ---------- */
function maybeNamePrompt(){
  if(state.catName) return;
  setTimeout(function(){
    document.getElementById('nameModal').classList.add('active');
  }, 500);
}
function submitName(){
  var val = document.getElementById('nameInput').value.trim();
  if(val){
    state.catName = val;
    addJournal('روزی که بالاخره یه اسم واقعی بهش دادم: ' + val + ' — از اون به بعد دیگه فقط "گربه" نبود 📛');
    saveState();
    renderTitle();
    updateMood_forceRefreshText();
  }
  document.getElementById('nameModal').classList.remove('active');
}
function updateMood_forceRefreshText(){
  var msg = document.getElementById('catMsg');
  var name = state.catName || 'گربه';
  if(mood === 'sad') msg.textContent = name + ' ناراحته... یکم بهش برس 🥺';
  else if(mood === 'happy') msg.textContent = name + ' خیلی خوشحاله و برات گل آورد 🌸';
  else msg.textContent = name + ' حالش خوبه 🐾';
}

/* ---------- journal ---------- */
function renderJournal(){
  var list = document.getElementById('journalList');
  list.innerHTML = '';
  if(state.journal.length === 0){
    var empty = document.createElement('p');
    empty.className = 'helpText';
    empty.style.textAlign = 'center';
    empty.textContent = 'هنوز خاطره‌ای ثبت نشده — باهاش بیشتر وقت بگذرون 🐾';
    list.appendChild(empty);
    return;
  }
  state.journal.forEach(function(j){
    var d = new Date(j.date);
    var row = document.createElement('div');
    row.className = 'journalItem';
    var t = document.createElement('span');
    t.textContent = j.title;
    var dt = document.createElement('span');
    dt.className = 'journalDate';
    dt.textContent = d.getFullYear()+'/'+(d.getMonth()+1)+'/'+d.getDate();
    row.appendChild(t);
    row.appendChild(dt);
    list.appendChild(row);
  });
}

/* ---------- night tint ---------- */
function updateNightTint(){
  var h = new Date().getHours();
  var isNight = h >= 0 && h < 6;
  document.getElementById('nightTint').classList.toggle('on', isNight);
}

/* ---------- golden heart / heart rain ---------- */
function triggerGoldenHeart(){
  var stage = document.getElementById('catStage');
  var el = document.createElement('div');
  el.className = 'goldHeart';
  el.textContent = '💛';
  stage.appendChild(el);
  setTimeout(function(){ el.remove(); }, 2000);
}
function maybeRareHeartRain(){
  if(document.getElementById('scr-home').classList.contains('active') && Math.random() < 0.05){
    var stage = document.getElementById('catStage');
    for(var i=0;i<8;i++){
      (function(i){
        setTimeout(function(){
          var h = document.createElement('div');
          h.className = 'heart';
          h.textContent = Math.random()>0.5 ? '💕' : '❤️';
          h.style.left = (Math.random()*180) + 'px';
          h.style.bottom = (Math.random()*140) + 'px';
          stage.appendChild(h);
          setTimeout(function(){ h.remove(); }, 1200);
        }, i*100);
      })(i);
    }
  }
}

/* ---------- shake to get treat ---------- */
var lastShakeTime = 0;
var shakeEnabled = false;
function setupShakeButton(){
  var needsPermission = typeof DeviceMotionEvent !== 'undefined' && typeof DeviceMotionEvent.requestPermission === 'function';
  if(needsPermission || typeof DeviceMotionEvent !== 'undefined'){
    document.getElementById('shakeEnableBtn').style.display = 'flex';
  }
}
function enableShake(){
  if(typeof DeviceMotionEvent !== 'undefined' && typeof DeviceMotionEvent.requestPermission === 'function'){
    DeviceMotionEvent.requestPermission().then(function(res){
      if(res === 'granted'){
        attachShakeListener();
        document.getElementById('shakeEnableBtn').style.display = 'none';
      } else {
        showToast('اجازه‌ی دسترسی به حس تکون داده نشد.');
      }
    }).catch(function(){
      showToast('این مرورگر از این قابلیت پشتیبانی نمی‌کنه.');
    });
  } else if(typeof DeviceMotionEvent !== 'undefined'){
    attachShakeListener();
    document.getElementById('shakeEnableBtn').style.display = 'none';
  } else {
    showToast('گوشیت این قابلیت رو نداره.');
  }
}
function attachShakeListener(){
  if(shakeEnabled) return;
  shakeEnabled = true;
  window.addEventListener('devicemotion', function(e){
    var a = e.accelerationIncludingGravity;
    if(!a) return;
    var mag = Math.sqrt((a.x||0)*(a.x||0) + (a.y||0)*(a.y||0) + (a.z||0)*(a.z||0));
    var now = Date.now();
    if(mag > 28 && now - lastShakeTime > 45000){
      lastShakeTime = now;
      dropTreat();
    }
  });
}
function dropTreat(){
  if(!document.getElementById('scr-home').classList.contains('active')) return;
  var stage = document.getElementById('catStage');
  var t = document.createElement('div');
  t.className = 'treatFall';
  t.textContent = Math.random() > 0.5 ? '🍬' : '🍎';
  stage.appendChild(t);
  setTimeout(function(){
    t.remove();
    state.food = Math.min(100, state.food + 8);
    updateBars(); updateMood();
    saveState();
    vibrate([15,15,15]);
    showToast('یه تشویقی از آسمون افتاد! 🍬');
  }, 700);
}

/* ---------- surprise gift box ---------- */
function maybeSpawnGiftBox(){
  if(!document.getElementById('scr-home').classList.contains('active')) return;
  if(document.querySelector('.giftBox')) return; // one at a time
  if(Math.random() < 0.12){
    var stage = document.getElementById('catStage');
    var box = document.createElement('div');
    box.className = 'giftBox';
    box.textContent = '🎁';
    box.style.left = (20 + Math.random()*70) + '%';
    box.style.top = (10 + Math.random()*20) + '%';
    box.onclick = function(){ collectGiftBox(box); };
    stage.appendChild(box);
    setTimeout(function(){ if(box.parentNode) box.remove(); }, 8000);
  }
}
function collectGiftBox(box){
  box.remove();
  vibrate([15,20,15]);
  var roll = Math.random();
  if(roll < 0.5){
    var keys = ['food','play','cuddle'];
    var k = keys[Math.floor(Math.random()*keys.length)];
    state[k] = Math.min(100, state[k] + 20);
    updateBars(); updateMood();
    showToast('یه هدیه‌ی غافلگیرکننده! (+۲۰ ' + (k==='food'?'غذا':k==='play'?'بازی':'بغل') + ')');
  } else {
    var remaining = ACCESSORY_POOL.filter(function(a){ return state.unlockedAccessories.indexOf(a) === -1; });
    if(remaining.length){
      var gift = remaining[Math.floor(Math.random()*remaining.length)];
      state.unlockedAccessories.push(gift);
      showToast('یه اکسسوری غافلگیرکننده: ' + gift + ' 🎁');
    } else {
      addXp(20);
      showToast('یه هدیه‌ی ویژه گرفتی! (+۲۰ امتیاز) 🎁');
    }
  }
  saveState();
}

/* ---------- helpers ---------- */
function vibrate(pattern){
  try{ if(navigator.vibrate) navigator.vibrate(pattern); }catch(e){}
}
function showToast(text){
  var t = document.createElement('div');
  t.className = 'toast';
  t.textContent = text;
  document.body.appendChild(t);
  setTimeout(function(){ t.remove(); }, 2600);
}

/* ---------- init ---------- */
(function init(){
  var saved = loadState();
  if(saved && saved.answered){
    state = saved;
    if(!state.bowOffset) state.bowOffset = {dx:0, dy:0};
    if(!state.milestones) state.milestones = {};
    if(typeof state.totalHeadPets !== 'number') state.totalHeadPets = 0;
    if(typeof state.xp !== 'number') state.xp = 0;
    if(!state.dailyLog) state.dailyLog = null;
    if(!state.dailySpecial) state.dailySpecial = null;
    var elapsedSec = Math.max(0, (Date.now() - state.lastUpdate) / 1000);
    var decayAmt = elapsedSec * (100/3600);
    state.food = Math.max(0, Math.round(state.food - decayAmt));
    state.play = Math.max(0, Math.round(state.play - decayAmt));
    state.cuddle = Math.max(0, Math.round(state.cuddle - decayAmt));
    state.lastUpdate = Date.now();
    mood = 'happy'; // force refresh below
    applyDailyReward();
    updateBars();
    mood = computeMood() === 'happy' ? 'notyet' : 'happy'; // ensure updateMood repaints
    updateMood();
    showScr('home');
    maybeNamePrompt();
    setupBowDrag();
    applyBowOffset();
  } else {
    updateBars();
  }
})();

if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('sw.js').catch(function(){});
  });
}
